import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import ProductForm from './components/ProductForm'; // Add product form
import ProductList from './components/ProductList'; // Product list page
import SellProduct from './components/SellProduct'; // Sell product page (if needed)
import AdminReviewsPage from './components/AdminReviewsPage'; // Reviews page

function App() {
  return (
    <Router>
      <div>
        <h1>Admin Panel</h1>
        
        {/* Navigation links */}
        <nav>
          <ul style={{ listStyleType: 'none', padding: 0 }}>
            <li style={{ display: 'inline', marginRight: '10px' }}>
              <Link to="/" style={{ textDecoration: 'none', color: 'blue' }}>Add Product</Link>
            </li>
            <li style={{ display: 'inline', marginRight: '10px' }}>
              <Link to="/product-list" style={{ textDecoration: 'none', color: 'blue' }}>Product List</Link>
            </li>
            <li style={{ display: 'inline', marginRight: '10px' }}>
              <Link to="/reviews" style={{ textDecoration: 'none', color: 'blue' }}>Product Reviews</Link>
            </li>
            <li style={{ display: 'inline', marginRight: '10px' }}>
              <Link to="/sell-product" style={{ textDecoration: 'none', color: 'blue' }}>Sell Product</Link>
            </li>
          </ul>
        </nav>

        {/* Routes */}
        <Routes>
          <Route path="/" element={<ProductForm />} /> 
          <Route path="/product-list" element={<ProductList />} /> 
          <Route path="/reviews" element={<AdminReviewsPage />} /> {/* Reviews page */}
          <Route path="/sell-product" element={<SellProduct />} /> {/* Sell Product page */}
          {/* Catch-all route for undefined paths */}
          <Route path="*" element={<h2>404 - Page Not Found</h2>} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;

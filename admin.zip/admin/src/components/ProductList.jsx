import React, { useState, useEffect } from 'react';
import axios from 'axios';

function ProductList() {
  const [products, setProducts] = useState([]);
  const [newStock, setNewStock] = useState({});  // Store new stock values

  // Fetch products from the backend
  useEffect(() => {
    axios.get('http://localhost:5000/api/products')
      .then(response => setProducts(response.data))
      .catch(error => console.error('Error fetching products:', error));
  }, []);

  // Handle stock update
  const handleStockUpdate = (productId) => {
    const enteredStock = newStock[productId];

    // Validate entered stock
    if (enteredStock === undefined || isNaN(enteredStock) || enteredStock <= 0) {
      alert('Please enter a valid stock value.');
      return;
    }

    // Send the new stock value to the backend
    axios.put(`http://localhost:5000/api/products/${productId}/stock`, { stock: Number(enteredStock) })
      .then(response => {
        // Update the product stock in the state
        setProducts(prevProducts =>
          prevProducts.map(product =>
            product._id === productId ? { ...product, stock: enteredStock } : product
          )
        );
        alert('Stock updated successfully');
      })
      .catch(error => console.error('Error updating stock:', error));
  };

  return (
    <div>
      <h2>Product List</h2>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Description</th>
            <th>Cost</th>
            <th>Stock</th>
            <th>Update Stock</th>
          </tr>
        </thead>
        <tbody>
          {products.map(product => (
            <tr key={product._id}>
              <td>{product.name}</td>
              <td>{product.description}</td>
              <td>{product.cost}</td>
              <td>{product.stock}</td>
              <td>
                <input
                  type="number"
                  value={newStock[product._id] || ''} // Ensure it's a valid number input
                  onChange={(e) => {
                    // Ensure to only update the stock as a number
                    setNewStock({ ...newStock, [product._id]: parseInt(e.target.value, 10) });
                  }}
                />
                <button onClick={() => handleStockUpdate(product._id)}>
                  Update Stock
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default ProductList;

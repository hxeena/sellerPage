import React, { useEffect, useState } from 'react';
import axios from 'axios';

function AdminReviewsPage() {
  const [reviews, setReviews] = useState([]);
  const [selectedProductId, setSelectedProductId] = useState('');
  const [products, setProducts] = useState([]);

  useEffect(() => {
    // Fetch products from the database to populate the dropdown
    axios.get('http://localhost:5000/api/products')  // Adjust to your products API
      .then(response => {
        setProducts(response.data);  // Assuming response.data contains product info
      })
      .catch(err => {
        console.error('Error fetching products:', err);
      });
  }, []);

  useEffect(() => {
    if (selectedProductId) {
      // Fetch reviews for the selected product
      axios.get(`http://localhost:5000/api/reviews/${selectedProductId}`)
        .then(response => {
          setReviews(response.data);
        })
        .catch(err => {
          console.error('Error fetching reviews:', err);
        });
    }
  }, [selectedProductId]);

  const handleProductChange = (e) => {
    setSelectedProductId(e.target.value);
  };

  return (
    <div>
      <h2>Product Reviews</h2>
      
      {/* Dropdown to select product */}
      <select onChange={handleProductChange} value={selectedProductId}>
        <option value="">Select a Product</option>
        {products.map(product => (
          <option key={product._id} value={product._id}>{product.name}</option>
        ))}
      </select>

      {/* List of reviews for the selected product */}
      {selectedProductId && reviews.length > 0 ? (
        <ul>
          {reviews.map(review => (
            <li key={review._id}>
              <p><strong>{review.username}:</strong> {review.comment}</p>
            </li>
          ))}
        </ul>
      ) : (
        selectedProductId && <p>No reviews available for this product.</p>
      )}
    </div>
  );
}

export default AdminReviewsPage;
